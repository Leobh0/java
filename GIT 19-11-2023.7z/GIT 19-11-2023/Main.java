import javax.swing.*;
import java.util.InputMismatchException;
import java.util.Scanner;

class Main extends JFrame {

    public static void main(String[] args) {
        new Calculadora();
        Soma soma = new Soma();
        Subtracao subtracao = new Subtracao();
        Multiplicacao multiplicacao = new Multiplicacao();
        Divisao divisao = new Divisao();
        MediaOperacao mediaOperacao = new MediaOperacao();


        System.out.println("Bem vindos a calculadora em JAVA! EBAA");

        Scanner teclado = new Scanner(System.in);
        double resultado = 0;

        while (true) {
            try {
                System.out.println("Digite o primeiro valor");
                double num1 = teclado.nextDouble();

                System.out.println("Digite a operação realizada (+, -, *, /)");
                char operacao = teclado.next().charAt(0);

                System.out.println("Digite o segundo valor");
                double num2 = teclado.nextDouble();

                switch (operacao) {
                    case '+':
                        resultado = soma.calcular(num1, num2);
                        break;
                    case '-':
                        resultado = subtracao.calcular(num1, num2);
                        break;
                    case '*':
                        resultado = multiplicacao.calcular(num1, num2);
                        break;
                    case '/':
                        if (num2 == 0) {
                            throw new ArithmeticException("Divisão por zero não é permitida.");
                        }
                        resultado = divisao.calcular(num1, num2);
                        break;
                    case '#':
                        resultado = mediaOperacao.calcular(num1, num2);
                        break;
                    default:
                        System.out.println("Operação inválida");
                        continue;
                }

                System.out.println("Resultado: " + resultado);

            } catch (InputMismatchException e) {
                System.out.println("Erro: Entrada inválida. Por favor, digite um número.");
                teclado.next(); // Limpa o buffer do scanner
            } catch (ArithmeticException e) {
                System.out.println("Erro: " + e.getMessage());
            }

            System.out.println("Digite 'e' para sair ou 'c' para a próxima operação.");
            char op = teclado.next().charAt(0);
            if (op == 'e') {
                System.exit(0);
            }
        }
    }
}