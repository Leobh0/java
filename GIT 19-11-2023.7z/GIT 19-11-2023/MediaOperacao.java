import java.util.ArrayList;

public class MediaOperacao extends OperacaoMatematica {

    public double calcular(double x, double y) {
        ArrayList<Double> numeros = new ArrayList<>();
        numeros.add(x);
        numeros.add(y);

        double soma = 0;
        for (double numero : numeros) {
            soma += numero;
        }

        double media = soma / numeros.size();

        return media;
    }
}
