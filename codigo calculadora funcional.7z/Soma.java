public class Soma extends OperacaoMatematica{

    public double calcular(double x, double y) {
        double resultado;
        return x + y;
    }
}