public class OperacaoMatematica{

    public double calcular(double x, double y) {
        return 0.0;
    }
}