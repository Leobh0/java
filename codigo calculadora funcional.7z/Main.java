import javax.swing.*;
import java.sql.SQLOutput;
import java.util.Scanner;

public class Main extends JFrame {

    public static void main(String[] args) {
        new Calculadora();
        Soma soma = new Soma();
        Subtracao subtracao = new Subtracao();
        Multiplicacao multiplicacao = new Multiplicacao();
        Divisao divisao = new Divisao();


        System.out.println("Bem vindos a calculadora em JAVA! EBAA");




        System.out.println("Digite o primeiro valor");
        double num1;
        Scanner teclado = new Scanner(System.in);
        num1 = teclado.nextDouble();


        System.out.println("Digite a operação realizada (+, -, *, /)");
        char operacao;
        operacao = teclado.next().charAt(0);


        System.out.println("Digite o segundo valor");
        double num2;
        num2 = teclado.nextDouble();

        double resultado = 0;


        switch (operacao) {
                case '+':
                    System.out.println(soma.calcular(num1, num2));
                    resultado = (soma.calcular(num1, num2));
                    break;
                case '-':
                    System.out.println(subtracao.calcular(num1, num2));
                    resultado = (subtracao.calcular(num1, num2));
                    break;
                case '*':
                    System.out.println(multiplicacao.calcular(num1, num2));
                    resultado = (multiplicacao.calcular(num1, num2));
                    break;
                case '/':
                    System.out.println(divisao.calcular(num1, num2));
                    resultado = (divisao.calcular(num1, num2));
                    break;
                default:
                    System.out.println("Operação inválida");
                    break;
        }

    int q = 0;

    while (q == 0) {

        System.out.println("Digite a operação realizada (+, -, *, /, e)");
        operacao = teclado.next().charAt(0);

        if (operacao == 'e'){
            System.exit(0);
        }

        System.out.println("Digite o proximo valor");
        double valor;
        valor = teclado.nextDouble();


        switch (operacao) {
            case '+':
                System.out.println(soma.calcular(resultado, valor));
                resultado = (soma.calcular(resultado, valor));
                break;
            case '-':
                System.out.println(subtracao.calcular(resultado, valor));
                resultado = (subtracao.calcular(resultado, valor));
                break;
            case '*':
                System.out.println(multiplicacao.calcular(resultado, valor));
                resultado = (multiplicacao.calcular(resultado, valor));
                break;
            case '/':
                System.out.println(divisao.calcular(resultado, valor));
                resultado = (divisao.calcular(resultado, valor));
                break;
            default:
                System.out.println("Operação inválida");
                break;
        }


    }



}
    }